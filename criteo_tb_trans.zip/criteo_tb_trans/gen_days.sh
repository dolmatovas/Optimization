#!/usr/bin/env bash
touch tmp.txt
for i in $(seq $1 $2); do
  echo $i
  time ~/criteo-script/gen_svm_data.sh day_$i tmp.txt 50
done
